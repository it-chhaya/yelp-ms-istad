package kh.edu.cstad.webbff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YelpWebBffApplication {

	public static void main(String[] args) {
		SpringApplication.run(YelpWebBffApplication.class, args);
	}

}
